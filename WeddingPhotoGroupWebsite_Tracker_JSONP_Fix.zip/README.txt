Wedding Photo Group Website - JSONP Tracker Fix

This version fixes the coordinator page by using JSONP script loading instead of fetch/POST/iframe.
This should work from GitHub Pages because it does not rely on cross-origin fetch writes.

Files included:
- index.html
- tracker.html
- style.css
- floral-left.png
- floral-right.png
- Code.gs
- README.txt

Add these yourself:
- guests.csv
- image1.jpg

CRITICAL SETUP:
1. Replace your Apps Script code with Code.gs from this package.
2. Deploy a NEW version:
   Deploy > Manage deployments > Edit pencil > Version: New version > Deploy
3. Use the Web App URL ending in /exec, not /dev.
4. Replace PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE in BOTH:
   - index.html
   - tracker.html
5. Push all website files to GitHub Pages.
6. Hard refresh the coordinator page with Ctrl + F5.

Google Sheet requirements:
- Sheet tab name must be exactly: PhotoTracker
- Headers must be: Group | Status
- Row examples:
  1 | Current
  2 | Pending
  3 | Pending

Test links:
1. Status:
   YOUR_WEB_APP_URL?action=status

2. Status via JSONP:
   YOUR_WEB_APP_URL?action=status&callback=testCallback
   This should display something like:
   testCallback({"success":true,"groups":[...]});

3. Complete Group 1:
   YOUR_WEB_APP_URL?action=complete&group=1

4. Reset:
   YOUR_WEB_APP_URL?action=reset
