Wedding Photo Group Website - Iframe Tracker Fix

This version fixes the coordinator update button by using a hidden iframe for write actions.
Why: your Apps Script GET links worked directly in the browser, but GitHub Pages may block fetch-based writes.
The iframe method loads the same working URL and triggers the update.

Files included:
- index.html
- tracker.html
- style.css
- floral-left.png
- floral-right.png
- Code.gs
- README.txt

Add these yourself:
- guests.csv
- image1.jpg

Important setup:
1. Keep your working Apps Script Code.gs from this package.
2. Deploy Apps Script as Web App:
   Execute as: Me
   Who has access: Anyone
3. After any Apps Script code change:
   Deploy > Manage deployments > Edit > New version > Deploy
4. Use the Web App URL ending in /exec.
5. Replace PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE in BOTH:
   - index.html
   - tracker.html
6. Push to GitHub Pages.

Testing:
1. Open tracker.html.
2. Unlock with passcode 0711.
3. Click Complete Group 1.
4. Watch the debug line under the green button.
5. Google Sheet should change:
   Group 1 -> Done
   Group 2 -> Current

If it still does not update:
- Open DevTools Console and check errors.
- Confirm tracker.html in GitHub has the new iframe code.
- Hard refresh: Ctrl + F5.
